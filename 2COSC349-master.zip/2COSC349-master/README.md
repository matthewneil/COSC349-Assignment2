# COSC349
Assignment 1 for COSC349 at the University of Otago.
