DROP TABLE timezones;

CREATE TABLE timezones (
	userID varchar(10),
	defaultzone varchar(4)
);

INSERT INTO timezones VALUES ("User", "NZT");
