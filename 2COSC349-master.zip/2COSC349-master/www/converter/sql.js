var mysql = require('mysql');

var connection = mysql.createConnection({
  host: '192.168.2.12',
  user: 'webuser',
  password: 'Quack1nce4^',
  database: 'timezones'
});

connection.connect(function(err) {
if (err) throw err;
  console.log("Connected!");
  var sql = "INSERT INTO timezones VALUES ('Company Inc', 5)";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");
  });
});
